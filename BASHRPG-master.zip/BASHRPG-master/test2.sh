for i in `shuf -n 5 database.txt`; do

	echo $i
	
done
